<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load necessary models, libraries, helpers, etc.
        $this->load->model('User_model');
        // Load other components as needed
    }

    public function login() {
        // Check if the user is already logged in, if yes, redirect
        if ($this->session->userdata('logged_in')) {
            redirect('events/dashboard'); // Redirect to the dashboard or home page
        }

        // Handle login form submission
        if ($this->input->post()) {
            
            // Validate login form data
            $email = $this->input->post('email');
            $password = md5($this->input->post('password'));
            // Example: Validate user credentials using User_model
            $loggedIn = $this->User_model->validateUser($email, $password);

            if ($loggedIn) {
                // Set session data indicating user is logged in
                $this->session->set_userdata('logged_in', true);
                redirect('events/dashboard'); // Redirect to dashboard on successful login
            } else {
                // Login failed, display error message, reload login form, etc.
                // You may want to set flashdata to show error messages
                redirect('auth/login'); // Redirect back to the login page
            }
        } else {
            // Load the login view
            $this->load->view('auth/login');
        }
    }

    public function logout() {
        // Destroy session data to log the user out
        $this->session->unset_userdata('logged_in');
        redirect('auth/login'); // Redirect to the login page after logout
    }

    // Other authentication-related methods can be added here
}
