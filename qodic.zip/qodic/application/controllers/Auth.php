<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load necessary models, libraries, helpers, etc.
        $this->load->model('User_model');
        // Load other components as needed
    }

    public function login() {
        if ($this->session->userdata('logged_in')) {
            redirect('events/dashboard');
        }

        if ($this->input->post()) {
            $email = $this->input->post('email');
            $password = md5($this->input->post('password'));

            $loggedIn = $this->User_model->validateUser($email, $password);

            if ($loggedIn) {
                $session_data = array(
                    'id' => $loggedIn->id,
                    'username' => $loggedIn->username,
                    'email' => $loggedIn->email,
                    'logged_in' => TRUE // You can set a flag to indicate the user is logged in
                );
                $this->session->set_userdata($session_data);
                redirect('events/dashboard');
            } else {
                redirect('auth/login');
            }
        } else {
            $this->load->view('auth/login');
        }
    }

    public function logout() {
        // Destroy session data to log the user out
        $this->session->sess_destroy();
        redirect('auth/login'); // Redirect to the login page after logout
    }

    // Other authentication-related methods can be added here
}
