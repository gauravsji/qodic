<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Events extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load necessary models, libraries, helpers, etc.
        $this->load->model('Event_model');
        // Load other components as needed
    }

    public function index() {
        // Fetch available events from the Event_model
        $data['events'] = $this->Event_model->getAvailableEvents();
        
        // Load view to display events
        $this->load->view('events/index', $data);
    }

    public function mybooking() {
        // Fetch available events from the Event_model
        $data['bookings'] = $this->Event_model->getbookedEvents();
        
        // Load view to display events
        $this->load->view('events/my_bookings', $data);
    }

    public function dashboard() {
        // Load view to display events
        $this->load->view('dashboard');
    }

    public function view($eventId) {
        // Fetch event details by ID
        $data['event'] = $this->Event_model->getEventById($eventId);
        
        // Load view to display event details
        $this->load->view('events/view', $data);
    }

    public function book($eventId) {
        // Check if the user is logged in
        if (!$this->session->userdata('id')) {
            // If not logged in, redirect to the login page
            redirect('auth/login');
        }

        // Handle booking process for the event
        if ($this->input->post()) {
            // Retrieve and validate booking form data
            // Assuming you have form fields such as fname, lname, etc.
            $bookingData = array(
                'user_id' => $this->session->userdata('id'), // Retrieve user ID from session
                // Other booking form data retrieval and validation
            );

            // Fetch event details (price, number of persons, etc.) based on event ID
            $eventDetails = $this->Event_model->getEventDetails($eventId);

            if ($eventDetails) {
                // Process booking using Event_model
                // Example: Calculate total charges, save booking details, etc.
                // Use $eventDetails to fetch necessary event information for the booking

                $bookingSuccess = $this->Event_model->bookEvent($bookingData);

                if ($bookingSuccess) {
                    // Booking successful
                    redirect('events/index'); // Redirect to events list or confirmation page
                } else {
                    // Booking failed
                    // Handle the failure, show an error message, etc.
                }
            } else {
                // Event details not found, handle accordingly
            }
        } else {
            // If the form wasn't submitted, redirect or handle as needed
            redirect('events/view/' . $eventId);
        }
    }

    // Other methods related to events can be added here
}
