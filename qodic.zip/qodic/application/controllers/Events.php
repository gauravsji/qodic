<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Events extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load necessary models, libraries, helpers, etc.
        $this->load->model('Event_model');
        // Load other components as needed
    }

    public function index() {
        // Fetch available events from the Event_model
        $data['events'] = $this->Event_model->getAvailableEvents();
        
        // Load view to display events
        $this->load->view('events/index', $data);
    }

    public function dashboard() {
        // Load view to display events
        $this->load->view('events/dashboard');
    }

    public function view($eventId) {
        // Fetch event details by ID
        $data['event'] = $this->Event_model->getEventById($eventId);
        
        // Load view to display event details
        $this->load->view('events/view', $data);
    }

    public function book($eventId) {
        // Handle booking process for the event
        if ($this->input->post()) {
            // Process booking form data
            $bookingData = array(
                // Retrieve and validate booking form data
                // Implement your logic to handle the booking
            );

            // Example: Save booking data using Event_model
            $bookingSuccess = $this->Event_model->bookEvent($bookingData);

            if ($bookingSuccess) {
                // Booking successful
                redirect('events/index'); // Redirect to events list or confirmation page
            } else {
                // Booking failed
                // Handle the failure, show an error message, etc.
            }
        } else {
            // If the form wasn't submitted, redirect or handle as needed
            redirect('events/view/' . $eventId);
        }
    }

    // Other methods related to events can be added here
}
