<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Event_model extends CI_Model {

    public function getAvailableEvents() {
        // Fetch available events from the database
        return $this->db->get('events')->result();
    }

    public function getEventById($eventId) {
        // Fetch event details by ID from the 'events' table
        $query = $this->db->get_where('events', array('id' => $eventId));
        return $query->row();
    }

    // Method to book an event (example)
    public function bookEvent($bookingData) {
        // Logic to process the booking and save data to the database
        // Implement your specific logic to handle the booking process
        // For example, inserting booking details into the bookings table

        // Example: Insert booking data into the 'bookings' table
        $this->db->insert('bookings', $bookingData);

        // Check if the booking was successful
        return ($this->db->affected_rows() > 0) ? true : false;
    }

    // Add more methods related to events as needed
}
