<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>

    <h2>Welcome to the Dashboard, <?php echo $this->session->userdata('username'); ?>!</h2>
    
    <!-- Logout button -->
    <form action="<?php echo base_url('auth/logout'); ?>" method="post">
        <input type="submit" value="Logout">
    </form>

    <!-- Add other dashboard content and functionalities as needed -->

    <a href="<?php echo base_url('events/index'); ?>">View Available Events</a> <!-- Link to view available events -->
    <a href="<?php echo base_url('events/mybooking'); ?>">View My Booking Events</a> <!-- Link to view available events -->

</body>
</html>
