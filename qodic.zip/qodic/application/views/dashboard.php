<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>

    <h2>Welcome to the Dashboard</h2>

    <!-- Add other dashboard content and functionalities as needed -->

    <a href="<?php echo site_url('events/index'); ?>">View Available Events</a> <!-- Link to view available events -->

</body>
</html>
