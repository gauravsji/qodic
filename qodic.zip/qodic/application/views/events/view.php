<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Details</title>
</head>
<body>

    <?php if (!empty($event)): ?>
        <h2><?php echo $event->name; ?></h2>
        <p><?php echo $event->description; ?></p>
        <!-- Display other event details -->

        <a href="<?php echo site_url('events/index'); ?>">Back to Events</a> <!-- Link to go back to events listing -->

        <!-- Example: Booking form -->
        <h3>Book Event</h3>
        <form method="post" action="<?php echo site_url('events/book/' . $event->id); ?>">
            <!-- Include form fields for booking -->
            <!-- Example: input fields for booking form -->
            <!-- Add logic to calculate charges, select event date-time, etc. -->
            <input type="submit" value="Book Now">
        </form>
    <?php else: ?>
        <p>Event not found.</p>
    <?php endif; ?>

</body>
</html>
