<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Details</title>
</head>
<body>

    <?php if (!empty($event)): ?>
        <a href="<?php echo site_url('events/index'); ?>">Back to Events</a> <!-- Link to go back to events listing -->

        <!-- Example: Booking form -->
        <h2>Book Event</h2>
        <h3><?php echo $event->name; ?></h3>
        <form method="post" action="<?php echo site_url('events/book/' . $event->id); ?>">
            <div class="row">
                <div class="col-md-6">
                    First Name
                </div>
                <div class="col-md-6">
                    <input type="text" id="fname" name="fname">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    Last Name
                </div>
                <div class="col-md-6">
                    <input type="text" id="lname" name="lname">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    Email
                </div>
                <div class="col-md-6">
                    <input type="email" id="email" name="email" value="<?php echo $this->session->userdata('email');?>" readonly>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    Mobile No.
                </div>
                <div class="col-md-6">
                    <input type="number" name="mobile" id="mobile">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    Charges
                </div>
                <div class="col-md-6">
                    <input type="number" name="charges" id="charges" value="<?php echo $event->charges_per_hour;?>" readolny>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <input type="submit" value="Book Now">
                </div>
            </div>
        </form>
    <?php else: ?>
        <p>Event not found.</p>
    <?php endif; ?>

</body>
</html>
