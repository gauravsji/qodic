<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Available Events</title>
</head>
<body>

    <h2>Available Events</h2>
    <a href="<?php echo site_url('auth/login'); ?>">Login</a> <!-- Link to the login page -->

    <?php if (!empty($events)): ?>
        <ul>
            <?php foreach ($events as $event): ?>
                <li>
                    <h3><?php echo $event->name; ?></h3>
                    <p><?php echo $event->description; ?></p>
                    <!-- Other event details -->
                    <a href="<?php echo site_url('events/view/' . $event->id); ?>">View Details</a>
                    <a href="<?php echo site_url('events/book/' . $event->id); ?>">Book Now</a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No events available.</p>
    <?php endif; ?>

</body>
</html>
