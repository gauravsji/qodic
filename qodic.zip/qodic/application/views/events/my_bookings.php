<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Bookings</title>
</head>
<body>

    <h2>My Bookings</h2>

    <?php if (!empty($bookings)): ?>
        <ul>
            <?php foreach ($bookings as $booking): ?>
                <li>
                    <h3><?php echo $booking->event_name; ?></h3>
                    <p>Booking Date: <?php echo $booking->booking_date; ?></p>
                    <!-- Display other booking details -->

                    <!-- Example: Cancel button for bookings within 1 hour -->
                    <?php 
                        $bookingTime = strtotime($booking->booking_date);
                        $currentTime = time();
                        $difference = $currentTime - $bookingTime;
                        $hoursDifference = floor($difference / (60 * 60)); // Convert seconds to hours

                        if ($hoursDifference <= 1): ?>
                            <a href="<?php echo site_url('events/cancel_booking/' . $booking->id); ?>">Cancel</a>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No bookings found.</p>
    <?php endif; ?>

</body>
</html>