<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Events';
$route['events/view/(:num)'] = 'events/view/$1';
$route['events/book/(:num)'] = 'events/book/$1';